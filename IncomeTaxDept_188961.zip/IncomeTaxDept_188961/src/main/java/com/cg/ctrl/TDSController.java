package com.cg.ctrl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.TDS;
import com.cg.service.TDSService;



@RestController
@RequestMapping("/tds")
public class TDSController {
	
	@Autowired
	TDSService tdsser;
	@GetMapping(value="/fetchtdsdetails",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<TDS> fetchAlltds()
	{
		return tdsser.fetchAlltds();
	}
	
	
	@PostMapping(path="/createtds/",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String createtds(@RequestBody TDS tds)
	{
		tdsser.createtds(tds);
		return ("data Inserted in MongoDB");		
	}
}
