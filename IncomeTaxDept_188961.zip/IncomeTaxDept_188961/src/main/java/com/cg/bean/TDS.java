package com.cg.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="tdsdetail")
public class TDS {
	@Id
	private int unique_id;
	private String deductor_name;
	private String deductor_pan;
	private long tds_deposited;
	public int getUnique_id() {
		return unique_id;
	}
	public void setUnique_id(int unique_id) {
		this.unique_id = unique_id;
	}
	public String getDeductor_name() {
		return deductor_name;
	}
	public void setDeductor_name(String deductor_name) {
		this.deductor_name = deductor_name;
	}
	public String getDeductor_pan() {
		return deductor_pan;
	}
	public void setDeductor_pan(String deductor_pan) {
		this.deductor_pan = deductor_pan;
	}
	public long getTds_deposited() {
		return tds_deposited;
	}
	public void setTds_deposited(long tds_deposited) {
		this.tds_deposited = tds_deposited;
	}
	@Override
	public String toString() {
		return "TDS [unique_id=" + unique_id + ", deductor_name=" + deductor_name + ", deductor_pan=" + deductor_pan
				+ ", tds_deposited=" + tds_deposited + "]";
	}
	public TDS() 
	{
	}
	public TDS(int unique_id, String deductor_name, String deductor_pan, long tds_deposited) {
		super();
		this.unique_id = unique_id;
		this.deductor_name = deductor_name;
		this.deductor_pan = deductor_pan;
		this.tds_deposited = tds_deposited;
	}
	
	
}
