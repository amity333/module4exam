package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.bean.TDS;
@Service
public interface TDSService {

	public List<TDS> fetchAlltds();
	public String createtds(TDS tds);
}
